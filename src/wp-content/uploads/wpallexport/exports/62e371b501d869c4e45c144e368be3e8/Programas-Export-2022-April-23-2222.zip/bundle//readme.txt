Los otros dos archivos en este zip son el archivo contenedor de la exportación de su datos y la plantilla de exportación para El Importador WP.

Para importar esta información, cree una nueva importación con El Importador WP y cargue este archivo zip.